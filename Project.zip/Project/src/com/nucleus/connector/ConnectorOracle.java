package com.nucleus.connector;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectorOracle {

	Connection con;
	public Connection getconn() throws SQLException, ClassNotFoundException
	{
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/SweetyDB","root", "root");
		return con;
	}
	
	public void closeConnection()
	{
		try {
			con.close();
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}


}
