package com.nucleus.domain;

import java.util.Date;

public class CustomerDomain {

	private long cust_id;
	private String cust_code;
	private String cust_name;
	private String cust_add1;
	private String cust_add2;
	private int pincode;
	private String email;
	private long cust_contactno;
	private String primary_contact;
	private String rec_status;
	private String aiflag;
	private String createdate;
	private String createdby;
	private String modifydate;
	private String modifyby;
	private String authdate;
	private String authby;
	
	public long getCust_id() {
		return cust_id;
	}
	public void setCust_id(String cust_id) {
		this.cust_id = Long.parseLong(cust_id);
	}
	
	public String getCust_code() {
		return cust_code;
	}
	public void setCust_code(String cust_code) {
		this.cust_code = cust_code;
	}
	public CustomerDomain() {
		
		cust_id =0;
		cust_code = null;
		cust_name = null;
		cust_add1 = null;
		cust_add2 = null;
		pincode = 0;
		email = null;
		cust_contactno = 0;
		primary_contact = null;
		rec_status = null;
		aiflag = null;
		createdate = null;
		createdby = null;
		modifydate = null;
		modifyby = null;
		authdate = null;
		authby = null;
	}
	public String getCust_name() {
		return cust_name;
	}
	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}
	public String getCust_add1() {
		return cust_add1;
	}
	public void setCust_add1(String cust_add1) {
		this.cust_add1 = cust_add1;
	}
	public String getCust_add2() {
		return cust_add2;
	}
	public void setCust_add2(String cust_add2) {
		this.cust_add2 = cust_add2;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = Integer.parseInt(pincode);
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getCust_contactno() {
		return cust_contactno;
	}
	public void setCust_contactno(String cust_contactno) {
		this.cust_contactno = Long.parseLong(cust_contactno);
	}
	public String getPrimary_contact() {
		return primary_contact;
	}
	public void setPrimary_contact(String primary_contact) {
		this.primary_contact = primary_contact;
	}
	public String getRec_status() {
		return rec_status;
	}
	public void setRec_status(String rec_status) {
		this.rec_status = rec_status;
	}
	public String getAiflag() {
		return aiflag;
	}
	public void setAiflag(String aiflag) {
		this.aiflag = aiflag;
	}
	public String getCreatedate() {
		return createdate;
	}
	public void setCreatedate(String createdate) {
		this.createdate = createdate;
	}
	public String getCreatedby() {
		return createdby;
	}
	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}
	public String getModifydate() {
		return modifydate;
	}
	public void setModifydate(String modifydate) {
		this.modifydate = modifydate;
	}
	public String getModifyby() {
		return modifyby;
	}
	public void setModifyby(String modifyby) {
		this.modifyby = modifyby;
	}
	public String getAuthdate() {
		return authdate;
	}
	public void setAuthdate(String authdate) {
		this.authdate = authdate;
	}
	public String getAuthby() {
		return authby;
	}
	public void setAuthby(String authby) {
		this.authby = authby;
	}
	
}
