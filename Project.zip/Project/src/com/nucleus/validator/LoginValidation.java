package com.nucleus.validator;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.sql.SQLException;

import com.nucleus.connector.ConnectorOracle;
import com.nucleus.domain.UserDetails;

public class LoginValidation {
	
	public ResultSet valuname(UserDetails u) throws ClassNotFoundException, SQLException
	{
		   
			ConnectorOracle conn=new ConnectorOracle();
			Connection con= conn.getconn();
			PreparedStatement p=con.prepareStatement("select * from LoginCredential where username=? and password=?");
			p.setString(1, u.getUsername());
			p.setString(2, u.getPassword());
			
			ResultSet rs=p.executeQuery();			
	
			
			return rs;
	}

}
