package com.nucleus.validator;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.regex.Pattern;

import com.nucleus.connector.ConnectorOracle;

public class CValidator {
	
	public boolean valname(String name)
	{
		boolean ans=Pattern.matches("[A-Z a-z 0-9]*", name);
		return ans&&name.length()<=30;
	}
	
	public boolean valpincode(String pin)
	{	
		//String p=pin.toString();
		boolean ans=(Pattern.matches("[0-9]*", pin))&&(pin.length()==6);
		return ans;
	}
	public boolean valemail(String email)
	{
		
		boolean ans1=Pattern.matches("[A-Za-z0-9][A-Za-z0-9_.]*@[A-Za-z]*.[A-za-z0-9]*",email);
		boolean ans2=Pattern.matches("[A-Za-z0-9][A-Za-z0-9_.]*@[A-Za-z]*.[a-z]*.[A-za-z0-9]*",email);
		return ((ans1 || ans2)&&(email.length()<=100));
	}
	
	public boolean valAIflag(String AIF)
	{
		return (Pattern.matches("[AI]",AIF));
	}
	
	public boolean valrecstatus(String RS)
	{
		return (Pattern.matches("[NMDAR]",RS));
	}
	
	public boolean lengthvalidations(String[] s)
	{
		return ((s[0].length()<=10)&&(s[1].length()<=30)&&(s[2].length()<=100)&&(s[3].length()<=100)&&((s[4].length()<=6))&&(s[5].length()<=100)&&(s[6].length()<=20)&&(s[7].length()<=100)&&(s[11].length()<=30)&&(s[13].length()<=30)&&(s[15].length()<=30));
	}
	
	public boolean pcvalidations(String s) throws SQLException, ClassNotFoundException
	{
		ConnectorOracle conn=new ConnectorOracle();
		Connection con= conn.getconn();
		PreparedStatement p=con.prepareStatement("select count(*) from cust16 where custcode=?");
		p.setString(1, s);
		ResultSet rs=p.executeQuery();
		rs.next();
		if(rs.getInt(1)!=0)
		return false;
		else return true;
	}

}
