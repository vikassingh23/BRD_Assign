package com.nucleus.dao;

import java.sql.Connection;
import java.util.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.nucleus.connector.ConnectorOracle;
import com.nucleus.domain.CustomerDomain;

public class CRUDImplement implements CRUDops{

	
	@Override
	public void Create(CustomerDomain c) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		ConnectorOracle conn=new ConnectorOracle();
		Connection con= conn.getconn();
		PreparedStatement ps=con.prepareStatement("insert into CUST16 values(seq16.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		ps.setString(1, c.getCust_code());
		ps.setString(2, c.getCust_name());
		ps.setString(3, c.getCust_add1());
		ps.setString(4,c.getCust_add2());
		ps.setInt(5, c.getPincode());
		ps.setString(6, c.getEmail());
		ps.setLong(7, c.getCust_contactno());
		ps.setString(8, c.getPrimary_contact());
		ps.setString(9,c.getRec_status());
		ps.setString(10, c.getAiflag());
		ps.setString(11, c.getCreatedate());
		ps.setString(12,c.getCreatedby());
		ps.setString(13, c.getModifydate());
		ps.setString(14,c.getModifydate());
		ps.setString(15, c.getAuthdate());
		ps.setString(16, c.getAuthby());
		ps.executeUpdate();
		con.commit();
	}

	@Override
	public ResultSet RetrieveAll() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		ConnectorOracle conn=new ConnectorOracle();
		Connection con= conn.getconn();
		PreparedStatement ps=con.prepareStatement("select * from cust16");
		ResultSet rs=ps.executeQuery();
		return rs;
	}

	@Override
	public ResultSet RetrieveByCode(String code) throws ClassNotFoundException, SQLException {
		
		ConnectorOracle conn=new ConnectorOracle();
		Connection con= conn.getconn();
		PreparedStatement ps=con.prepareStatement("select * from cust16 where custcode=?");
		ps.setString(1, code);
		ResultSet rs=ps.executeQuery();
		return rs;
	}

	@Override
	public void UpdateByCode(CustomerDomain c) throws SQLException, ClassNotFoundException {
		ConnectorOracle conn=new ConnectorOracle();
		Connection con= conn.getconn();
		PreparedStatement ps1=con.prepareStatement("delete from cust16 where custcode=?");
		ps1.setString(1, c.getCust_code());
		ps1.executeUpdate();
		
		PreparedStatement ps=con.prepareStatement("insert into CUST16 values(seq16.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		ps.setString(1, c.getCust_code());
		ps.setString(2, c.getCust_name());
		ps.setString(3, c.getCust_add1());
		ps.setString(4,c.getCust_add2());
		ps.setInt(5, c.getPincode());
		ps.setString(6, c.getEmail());
		ps.setLong(7, c.getCust_contactno());
		ps.setString(8, c.getPrimary_contact());
		ps.setString(9,c.getRec_status());
		ps.setString(10, c.getAiflag());
		ps.setString(11, c.getCreatedate());
		ps.setString(12,c.getCreatedby());
		ps.setString(13, c.getModifydate());
		ps.setString(14,c.getModifydate());
		ps.setString(15, c.getAuthdate());
		ps.setString(16, c.getAuthby());
		ps.executeUpdate();
		con.commit();

	}
	

	@Override
	public void DeleteByCode(String code) throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		ConnectorOracle conn=new ConnectorOracle();
		Connection con= conn.getconn();
		PreparedStatement ps1=con.prepareStatement("delete from cust16 where custcode=?");
		ps1.setString(1, code);
		ps1.executeUpdate();
		
		
	}

	@Override
	public void approve(String code,String name,String recs) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		String a="";
		if(recs.equals("N")||recs.equals("M"))
		{
		a="A";
		ConnectorOracle conn=new ConnectorOracle();
		Connection con= conn.getconn();
		
		PreparedStatement ps=con.prepareStatement("select * from cust16 where custcode=?");
		ps.setString(1, code);
		Date d=new Date();
		ResultSet rs=ps.executeQuery();
		rs.next();
		System.out.println(rs.getString(2) + rs.getString(3)+ rs.getString(4)+rs.getString(5)+rs.getString(6)+rs.getString(7)+rs.getString(8)+rs.getString(9)+rs.getString(10)+rs.getString(11)+rs.getString(12)+rs.getString(13)+rs.getString(14)+rs.getString(15)+rs.getString(16)+rs.getString(17) );
		PreparedStatement ps1=con.prepareStatement("insert into custmaster values(seq16.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		ps1.setString(1, rs.getString(2) );
		ps1.setString(2,rs.getString(3) );
		ps1.setString(3,rs.getString(4) );
		ps1.setString(4,rs.getString(5));
		ps1.setInt(5, Integer.parseInt(rs.getString(6)));
		ps1.setString(6,rs.getString(7));
		ps1.setLong(7, Long.parseLong(rs.getString(8)));
		ps1.setString(8,rs.getString(9));
		ps1.setString(9,a);
		ps1.setString(10,rs.getString(11) );
		ps1.setString(11, rs.getString(12));
		ps1.setString(12,rs.getString(13));
		ps1.setString(13, rs.getString(14));
		ps1.setString(14,rs.getString(15));
		ps1.setString(15, d.toString());
		ps1.setString(16, name);
		ps1.executeUpdate();
		 ps=con.prepareStatement("delete from cust16 where custcode=?");
		 ps.setString(1, code);
		ps.executeUpdate();
		}
		else if(recs.equals("D"))
		{
			ConnectorOracle conn=new ConnectorOracle();
			Connection con= conn.getconn();
			
			PreparedStatement ps=con.prepareStatement("delete from cust16 where custcode=?");
			ps.setString(1, code);
			ps.executeUpdate();
			PreparedStatement ps1=con.prepareStatement("delete from  custmaster where custcode=?");
			ps1.setString(1, code);
			ps1.executeUpdate();	
		}
		
	}

	@Override
	public void reject(String code, String name,String recs) throws ClassNotFoundException,
			SQLException {
		// TODO Auto-generated method stub
		String a="";
		if(recs.equals("N"))
		{
			a="NR";
		}
		else if(recs.equals("M"))
		{
			a="MR";
		}
		else if(recs.equals("D"))
		{
			a="DR";
		}
		
		ConnectorOracle conn=new ConnectorOracle();
		Connection con= conn.getconn();
		Date d=new Date();
		PreparedStatement ps=con.prepareStatement("Update cust16 set recordstatus=?,AUTHORIZEDDATE=?,AURORIZEDBY=? where CUSTCODE=?");
		ps.setString(1, a);
		ps.setString(2, d.toString());
		ps.setString(3, name);
		ps.setString(4, code);
		ps.executeUpdate();
		con.commit();
		
		
	}

	@Override
	public ResultSet RetrieveMByCode(String code)
			throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
		ConnectorOracle conn=new ConnectorOracle();
		Connection con= conn.getconn();
		PreparedStatement ps=con.prepareStatement("select * from custmaster where custcode=?");
		ps.setString(1, code);
		ResultSet rs=ps.executeQuery();
		con.commit();
		return rs;
	}
	public void UpdateRecSt(String code,String recs,String name) throws ClassNotFoundException, SQLException
	{
		ConnectorOracle conn=new ConnectorOracle();
		Connection con= conn.getconn();
		PreparedStatement ps=con.prepareStatement("select * from custmaster where custcode=?");
		ps.setString(1, code);
		ResultSet Rs=ps.executeQuery();
		Rs.next();
		Date d=new Date();
		String a="";
		if(name.equals("del"))
		{
			a="D";
		}
		else if(name.equals("mod"))
		{
			a="M";
		}
			PreparedStatement ps1=con.prepareStatement("insert into cust16 values(seq16.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			ps1.setString(1, Rs.getString(2) );
			ps1.setString(2,Rs.getString(3) );
			ps1.setString(3,Rs.getString(4) );
			ps1.setString(4,Rs.getString(5));
			ps1.setInt(5, Integer.parseInt(Rs.getString(6)));
			ps1.setString(6,Rs.getString(7));
			ps1.setLong(7, Long.parseLong(Rs.getString(8)));
			ps1.setString(8,Rs.getString(9));
			ps1.setString(9,a);
			ps1.setString(10,Rs.getString(11) );
			ps1.setString(11, Rs.getString(12));
			ps1.setString(12,Rs.getString(13));
			ps1.setString(13, Rs.getString(14));
			ps1.setString(14,Rs.getString(15));
			ps1.setString(15, d.toString());
			ps1.setString(16, Rs.getString(17));
			ps1.executeUpdate();
			con.commit();
			
		
	}
	public boolean inMaster(String code) throws ClassNotFoundException, SQLException
	{
		ConnectorOracle conn=new ConnectorOracle();
		Connection con= conn.getconn();
		PreparedStatement ps=con.prepareStatement("select * from custmaster where custcode=?");
		ps.setString(1, code);
		ResultSet rs=ps.executeQuery();
		con.commit();
		if(rs.next())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean inCust(String code) throws ClassNotFoundException, SQLException
	{
		ConnectorOracle conn=new ConnectorOracle();
		Connection con= conn.getconn();
		PreparedStatement ps=con.prepareStatement("select * from cust16 where custcode=?");
		ps.setString(1, code);
		ResultSet rs=ps.executeQuery();
		con.commit();
		if(rs.next())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	

}
