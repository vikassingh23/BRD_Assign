package com.nucleus.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.nucleus.domain.CustomerDomain;

public interface CRUDops {
	
	public void Create(CustomerDomain c) throws ClassNotFoundException, SQLException;
	public ResultSet RetrieveAll() throws ClassNotFoundException, SQLException;
	public ResultSet RetrieveByCode(String code) throws ClassNotFoundException, SQLException;
	public void UpdateByCode(CustomerDomain c) throws SQLException, ClassNotFoundException;
	public void DeleteByCode(String code) throws SQLException, ClassNotFoundException;
	public void approve(String code,String name,String recs) throws ClassNotFoundException, SQLException;
	public void reject(String code,String name,String recs) throws ClassNotFoundException, SQLException;
	public ResultSet RetrieveMByCode(String code) throws ClassNotFoundException, SQLException;
	public void UpdateRecSt(String code,String recs,String name) throws ClassNotFoundException, SQLException;
}
