package com.nucleus.controller;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Date;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.nucleus.validator.*;
import com.nucleus.dao.CRUDImplement;
import com.nucleus.dao.CRUDops;
import com.nucleus.domain.CustomerDomain;

@WebServlet("/CreateValidate")
public class CreateValidate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public CreateValidate() {
        super();
    }

		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			doProcess(request,response);
		} catch (ClassNotFoundException e) {
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
	protected void doProcess(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException, ClassNotFoundException, SQLException
	{
		response.setContentType("text/html");
		HttpSession session=request.getSession();
		String name=(String)session.getAttribute("name");
		//CustomerDomain c= new CustomerDomain();
		String code=request.getParameter("ccode");
		String cname=request.getParameter("cname");
		String add1=request.getParameter("add1");
		String add2=request.getParameter("add2");
		String pin=request.getParameter("pc");
		String email=request.getParameter("email");
		String cno=request.getParameter("cno");
		String pcp=request.getParameter("pcp");
		String aif=request.getParameter("aif");
		
		CValidator cv= new CValidator();
		boolean v1=cv.valname(cname);
		boolean v2=cv.valemail(email);
		boolean v3=cv.valpincode(pin);
		boolean v4=cv.pcvalidations(code);

			
		if(v1==false||v2==false||v3==false || v4==false)
		{
			PrintWriter out=response.getWriter();
			out.println(" \n ");
		    out.println("-------------  Error in one of the fields! --------------");
		    out.println(" \n ");
			RequestDispatcher rq= request.getRequestDispatcher("create.jsp");
			rq.include(request, response);
			
		}
		else
		{
			CustomerDomain c1=new CustomerDomain();
			c1.setAiflag(aif);
			c1.setCust_name(cname);
			c1.setCreatedby(name);
			c1.setCust_add1(add1);
			c1.setCust_add2(add2);
			c1.setPincode(pin);
			c1.setEmail(email);
			c1.setCust_contactno(cno);
			c1.setPrimary_contact(pcp);
			c1.setCust_code(code);
			Date d=new  Date();
			//SimpleDateFormat ft= new SimpleDateFormat("dd/MM/yyyy");
			c1.setCreatedate(d.toString());
			c1.setRec_status("N");
			
			CRUDops co= new CRUDImplement();
			co.Create(c1);
			response.sendRedirect("maker.jsp");
			
		}
		
		
	}

}
