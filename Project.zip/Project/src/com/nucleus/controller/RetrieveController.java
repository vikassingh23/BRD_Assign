package com.nucleus.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.nucleus.dao.CRUDImplement;
import com.nucleus.dao.CRUDops;
import com.nucleus.domain.CustomerDomain;


@WebServlet("/RetrieveController")
public class RetrieveController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
     public RetrieveController() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			doProcess(request,response);
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
	protected void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, ClassNotFoundException, SQLException 
	{
		String a=request.getParameter("rad");
		HttpSession session=request.getSession();
		response.setContentType("text/html");
		
		if(a.equals("rall"))
		{
			CRUDops cr= new CRUDImplement();
			ResultSet r=cr.RetrieveAll();
			List<CustomerDomain> li= new ArrayList<CustomerDomain>();
			while(r.next())
			{
				CustomerDomain c=new CustomerDomain();
				c.setCust_code(r.getString(2));
				c.setCust_name(r.getString(3));
				c.setCust_add1(r.getString(4));
				c.setCust_add2(r.getString(5));
				c.setPincode(r.getString(6));
				c.setEmail(r.getString(7));
				c.setCust_contactno(r.getString(8));
				c.setPrimary_contact(r.getString(9));
				c.setRec_status(r.getString(10));
				c.setAiflag(r.getString(11));
				c.setCreatedate(r.getString(12));
				c.setCreatedby(r.getString(13));
				c.setModifydate(r.getString(14));
				c.setModifyby(r.getString(15));
				c.setAuthdate(r.getString(16));
				c.setAuthby(r.getString(17));
				li.add(c);
			}
			
			session.setAttribute("list", li);
			response.sendRedirect("retrive.jsp");
		}
		else if(a.equals("rpa"))
		{
			String b=request.getParameter("cco");
			CRUDops cr= new CRUDImplement();
			ResultSet r=cr.RetrieveByCode(b);
			if(r.next())
			{
				List<CustomerDomain> li= new ArrayList<CustomerDomain>();
				CustomerDomain c=new CustomerDomain();
				c.setCust_code(r.getString(2));
				c.setCust_name(r.getString(3));
				c.setCust_add1(r.getString(4));
				c.setCust_add2(r.getString(5));
				c.setPincode(r.getString(6));
				c.setEmail(r.getString(7));
				c.setCust_contactno(r.getString(8));
				c.setPrimary_contact(r.getString(9));
				c.setRec_status(r.getString(10));
				c.setAiflag(r.getString(11));
				c.setCreatedate(r.getString(12));
				c.setCreatedby(r.getString(13));
				c.setModifydate(r.getString(14));
				c.setModifyby(r.getString(15));
				c.setAuthdate(r.getString(16));
				c.setAuthby(r.getString(17));
				li.add(c);
				session.setAttribute("list", li);
				response.sendRedirect("retrive.jsp");
			}
			else
			{
				PrintWriter out=response.getWriter();
				out.println("No such Record found!!");
				RequestDispatcher rd=request.getRequestDispatcher("retchoice.html");
				rd.include(request, response);
			}
		}
	}
}
