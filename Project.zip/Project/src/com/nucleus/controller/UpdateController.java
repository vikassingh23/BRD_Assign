package com.nucleus.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.nucleus.dao.CRUDImplement;
import com.nucleus.dao.CRUDops;
import com.nucleus.domain.CustomerDomain;

/**
 * Servlet implementation class UpdateController
 */
@WebServlet("/UpdateController")
public class UpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			doProcess(request,response);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	protected void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, ClassNotFoundException, SQLException
	{
		String a=request.getParameter("cu");
		HttpSession session=request.getSession();
		response.setContentType("text/html");
		CRUDImplement cr= new CRUDImplement();
		//ResultSet r=cr.RetrieveByCode(a);
		//r.next();
		String name=request.getParameter("name");
		Date d=new Date();
		ResultSet r1=cr.RetrieveMByCode(a);
		r1.next();
		if((cr.inCust(a)&& !cr.inMaster(a) ))
		{	
			ResultSet r=cr.RetrieveByCode(a);
			if(r.next())
			{
			String aa="";	
			CustomerDomain c=new CustomerDomain();
			if(r.getString(10).equals("N")||r.getString(10).equals("NR"))
			{
				aa="N";
			}
			else if(r.getString(10).equals("MR"))
			{
				aa="M";
			}
			c.setCust_code(r.getString(2));
			c.setCust_name(r.getString(3));
			c.setCust_add1(r.getString(4));
			c.setCust_add2(r.getString(5));
			c.setPincode(r.getString(6));
			c.setEmail(r.getString(7));
			c.setCust_contactno(r.getString(8));
			c.setPrimary_contact(r.getString(9));
			c.setRec_status(aa);
			c.setAiflag(r.getString(11));
			c.setCreatedate(r.getString(12));
			c.setCreatedby(r.getString(13));
			c.setModifydate(d.toString());
			c.setModifyby(name);
			c.setAuthdate(r.getString(16));
			c.setAuthby(r.getString(17));
			session.setAttribute("cust", c);
			response.sendRedirect("UpdateView.jsp");	
			}
		}
		else if(cr.inMaster(a)&&!cr.inCust(a) || cr.inMaster(a)&& cr.inCust(a))
		{
			ResultSet r=cr.RetrieveMByCode(a);
			if(r.next())
			{
				String a1=r.getString(10);
				CustomerDomain c=new CustomerDomain();
				c.setCust_code(r.getString(2));
				c.setCust_name(r.getString(3));
				c.setCust_add1(r.getString(4));
				c.setCust_add2(r.getString(5));
				c.setPincode(r.getString(6));
				c.setEmail(r.getString(7));
				c.setCust_contactno(r.getString(8));
				c.setPrimary_contact(r.getString(9));
				c.setRec_status("M");
				c.setAiflag(r.getString(11));
				c.setCreatedate(r.getString(12));
				c.setCreatedby(r.getString(13));
				c.setModifydate(d.toString());
				c.setModifyby(name);
				c.setAuthdate(r.getString(16));
				c.setAuthby(r.getString(17));
				session.setAttribute("cust", c);
				response.sendRedirect("UpdateView.jsp");
				
			}
		}
	
		else
		{
			PrintWriter out=response.getWriter();
			out.println("No such Record found!!");
			RequestDispatcher rd=request.getRequestDispatcher("updatechoice.html");
			rd.include(request, response);
		}

	}

}
