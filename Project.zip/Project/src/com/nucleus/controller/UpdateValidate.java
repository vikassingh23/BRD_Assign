package com.nucleus.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.nucleus.dao.CRUDImplement;
import com.nucleus.dao.CRUDops;
import com.nucleus.domain.CustomerDomain;
import com.nucleus.validator.CValidator;

/**
 * Servlet implementation class UpdateValidate
 */
@WebServlet("/UpdateValidate")
public class UpdateValidate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateValidate() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			doProcess(request,response);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	protected void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, ClassNotFoundException, SQLException
	{
		response.setContentType("text/html");
		HttpSession session=request.getSession();
		String name=(String)session.getAttribute("name");
		//CustomerDomain c= new CustomerDomain();
		String code=request.getParameter("ccode");
		String cname=request.getParameter("cname");
		String add1=request.getParameter("add1");
		String add2=request.getParameter("add2");
		String pin=request.getParameter("pc");
		String email=request.getParameter("email");
		String cno=request.getParameter("cno");
		String pcp=request.getParameter("pcp");
		String aif=request.getParameter("aif");
		
		CValidator cv= new CValidator();
		boolean v1=cv.valname(cname);
		boolean v2=cv.valemail(email);
		boolean v3=cv.valpincode(pin);
		//boolean v4=cv.pcvalidations(code);

		
				
		
		
		if(v1==false||v2==false||v3==false)
		{
			PrintWriter out=response.getWriter();
		    out.println("Error in one of the fields!");
		    RequestDispatcher r=request.getRequestDispatcher("UpdateView.jsp");
		    r.include(request, response);
		}
		else
		{
			CustomerDomain c1=new CustomerDomain();
			CustomerDomain c=new CustomerDomain();
			c=(CustomerDomain)session.getAttribute("cust");
			c1.setAiflag(aif);
			c1.setCust_name(cname);
			c1.setCreatedby(c.getCreatedby());
			c1.setCust_add1(add1);
			c1.setCust_add2(add2);
			c1.setPincode(pin);
			c1.setEmail(email);
			c1.setCust_contactno(cno);
			c1.setPrimary_contact(pcp);
			c1.setCust_code(code);
			Date d=new  Date();
			SimpleDateFormat ft= new SimpleDateFormat("dd/MM/yyyy");
			
			c1.setCreatedate(c.getCreatedate()); 
			c1.setRec_status("M");
			c1.setModifyby(name);
			c1.setModifydate(d.toString());
			
			CRUDops co= new CRUDImplement();
			co.UpdateByCode(c1);
			response.sendRedirect("maker.jsp");
			
		}
		
		
	}
	}

