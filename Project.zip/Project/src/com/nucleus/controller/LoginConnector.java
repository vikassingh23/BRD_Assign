package com.nucleus.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.nucleus.dao.CRUDImplement;
import com.nucleus.dao.CRUDops;
import com.nucleus.domain.CustomerDomain;
import com.nucleus.domain.UserDetails;
import com.nucleus.validator.LoginValidation;


@WebServlet("/LoginConnector")
public class LoginConnector extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public LoginConnector() {
        super();
       
    }

	
    protected void doProcess(HttpServletRequest request, HttpServletResponse response) throws IOException, ClassNotFoundException, SQLException, ServletException
    {
    	response.setContentType("text/html");
    	PrintWriter out=response.getWriter();
    	
    	String uname=request.getParameter("username");
    	String pw=request.getParameter("password");
    	
    	UserDetails u1=new UserDetails();
    	u1.setPassword(pw);
    	u1.setUsername(uname);
    	
    	LoginValidation l=new LoginValidation();
    	ResultSet r=l.valuname(u1);
    	
    	
    	if(r.next())
    	{
    		System.out.println(r.getString(1) + r.getString(2) + r.getString(3));
    		
        	HttpSession session = request.getSession();
        	session.setAttribute("name", u1.getUsername());
    		if(r.getString(3).equals("maker"))
    	
    		{
    			/*RequestDispatcher re= request.getRequestDispatcher("maker.jsp");
        		re.include(request, response);*/
    			response.sendRedirect("maker.jsp");
    		}
    		else if(r.getString(3).equals("checker"))
    		{
    			/*CRUDops cr= new CRUDImplement();
    			ResultSet rs=cr.RetrieveAll();
    			List<CustomerDomain> li= new ArrayList<CustomerDomain>();
    			while(rs.next())
    			{
    				CustomerDomain c=new CustomerDomain();
    				c.setCust_code(rs.getString(2));
    				c.setCust_name(rs.getString(3));
    				c.setCust_add1(rs.getString(4));
    				c.setCust_add2(rs.getString(5));
    				c.setPincode(rs.getString(6));
    				c.setEmail(rs.getString(7));
    				c.setCust_contactno(rs.getString(8));
    				c.setPrimary_contact(rs.getString(9));
    				c.setRec_status(rs.getString(10));
    				c.setAiflag(rs.getString(11));
    				c.setCreatedate(rs.getString(12));
    				c.setCreatedby(rs.getString(13));
    				c.setModifydate(rs.getString(14));
    				c.setModifyby(rs.getString(15));
    				c.setAuthdate(rs.getString(16));
    				c.setAuthby(rs.getString(17));
    				li.add(c);
    			}*/
    		//	session.setAttribute("list", li);
    			RequestDispatcher re= request.getRequestDispatcher("checkerWelcomePage.jsp");
        		re.include(request, response);
    		}
    	
    	
    	}
    	else
    	{
    		out.println(" \n ");
    		out.println(" ----------------   username or passwrod incorrect! ----------------");
    		out.println(" \n ");
    		RequestDispatcher re= request.getRequestDispatcher("login.jsp");
    		re.include(request, response);
    	}	
    	
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		try {
			doProcess(request,response);
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}

}
