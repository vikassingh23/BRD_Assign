package com.nucleus.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.nucleus.dao.CRUDImplement;
import com.nucleus.dao.CRUDops;

/**
 * Servlet implementation class DeleteController
 */
@WebServlet("/DeleteController")
public class DeleteController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			doProcess(request,response);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
	}
	protected void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, ClassNotFoundException, SQLException 
	{
		response.setContentType("text/html");
		String a=request.getParameter("du");
		CRUDops c= new CRUDImplement();
		ResultSet r=c.RetrieveByCode(a);
		r.next();
		ResultSet rm=c.RetrieveMByCode(a);
		rm.next();
		PrintWriter out=response.getWriter();
		HttpSession session=request.getSession();
		String name=(String)session.getAttribute("name");
		CRUDImplement co=new CRUDImplement();
		if((!co.inMaster(a)&&co.inCust(a))||(co.inCust(a) && co.inMaster(a))) 
		{
			
			co.DeleteByCode(a);
			out.println("Deletion Successful from Temp table!");
			RequestDispatcher rq=request.getRequestDispatcher("maker.jsp");
			rq.include(request, response);
		}
		else if(co.inMaster(a) && !co.inCust(a))
		{
			String a1=rm.getString(10);
			co.UpdateRecSt(a, a1,"del");
			out.println("Deletion Requested to the Checker");
			//{out.println("Cannot request to delete an approved record");}
			RequestDispatcher rq=request.getRequestDispatcher("maker.jsp");
			rq.include(request, response);
			
		}
		else if(!co.inCust(a) && !co.inMaster(a))
		{
			
			out.println("No Such Record Found");
			RequestDispatcher rq=request.getRequestDispatcher("delete.html");
			rq.include(request, response);
			
		}
		
				
	}
}
