package com.nucleus.makerchecker.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.nucleus.makerchecker.connectionfac.ConnectionFactory;
import com.nucleus.makerchecker.model.Customer;

public class CustomerDao {
	
	private Connection connection;
	
	public CustomerDao(){
		connection = ConnectionFactory.getConnection();
	}
	
	public void addCustomer(Customer customer){
		try{
		PreparedStatement ps=connection.prepareStatement("insert into CUST16 values(seq16.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		ps.setString(1, customer.getCustomer_code());
		ps.setString(2, customer.getCustomer_name());
		ps.setString(3, customer.getCustomer_add1());
		ps.setString(4,customer.getCustomer_add2());
		ps.setInt(5, customer.getPincode());
		ps.setString(6, customer.getEmail());
		ps.setLong(7, customer.getCustomer_contactno());
		ps.setString(8, customer.getPrimary_contact());
		ps.setString(9,customer.getRecord_status());
		ps.setString(10, customer.getAiflag());
		ps.setString(11, customer.getCreatedate());
		ps.setString(12,customer.getCreatedby());
		ps.setString(13, customer.getModifydate());
		ps.setString(14,customer.getModifydate());
		ps.setString(15, customer.getAuthdate());
		ps.setString(16, customer.getAuthby());
		ps.executeUpdate();
		connection.commit();
		System.out.println("completed");
		}catch(Exception e){
			System.out.println(e);
		}
	}
	
	
	
	
	

}
