package com.nucleus.makerchecker.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDao {
	
	public static boolean validate(String name,String pass){
		System.out.println(name);
		System.out.println(pass);
		boolean status=false;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","scott","vikas");
			
			PreparedStatement ps=con.prepareStatement("select * from userreg where name=? and pass=?");
			//PreparedStatement ps=con.prepareStatement("select * from userreg");
			ps.setString(1,name);
			ps.setString(2,pass);
			
			ResultSet rs=ps.executeQuery();
			
			status=rs.next();
			System.out.println(status);
			
		}catch(Exception e){System.out.println(e);}
		return status;
		}
	
	

}
