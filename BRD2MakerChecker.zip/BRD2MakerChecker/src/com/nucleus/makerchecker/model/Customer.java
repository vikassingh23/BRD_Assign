package com.nucleus.makerchecker.model;

public class Customer {
	
	private long customer_id;
	private String customer_code;
	private String customer_name;
	private String customer_add1;
	private String customer_add2;
	private int pincode;
	private String email;
	private long customer_contactno;
	private String primary_contact;
	private String record_status;
	private String aiflag;
	private String createdate;
	private String createdby;
	private String modifydate;
	private String modifyby;
	private String authdate;
	private String authby;
		
	public Customer() {
	}

	public Customer(long customer_id, String customer_code, String customer_name, String customer_add1,
			String customer_add2, int pincode, String email, long customer_contactno, String primary_contact,
			String record_status, String aiflag, String createdate, String createdby, String modifydate,
			String modifyby, String authdate, String authby) {
		this.customer_id = customer_id;
		this.customer_code = customer_code;
		this.customer_name = customer_name;
		this.customer_add1 = customer_add1;
		this.customer_add2 = customer_add2;
		this.pincode = pincode;
		this.email = email;
		this.customer_contactno = customer_contactno;
		this.primary_contact = primary_contact;
		this.record_status = record_status;
		this.aiflag = aiflag;
		this.createdate = createdate;
		this.createdby = createdby;
		this.modifydate = modifydate;
		this.modifyby = modifyby;
		this.authdate = authdate;
		this.authby = authby;
	}
	
	public long getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(long customer_id) {
		this.customer_id = customer_id;
	}
	
	public String getCustomer_code() {
		return customer_code;
	}
	public void setCustomer_code(String customer_code) {
		this.customer_code = customer_code;
	}
	
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	
	public String getCustomer_add1() {
		return customer_add1;
	}
	public void setCustomer_add1(String customer_add1) {
		this.customer_add1 = customer_add1;
	}
	
	public String getCustomer_add2() {
		return customer_add2;
	}
	public void setCustomer_add2(String customer_add2) {
		this.customer_add2 = customer_add2;
	}
	
	public int getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = Integer.parseInt(pincode);
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public long getCustomer_contactno() {
		return customer_contactno;
	}
	public void setCustomer_contactno(String cno) {
		this.customer_contactno = Long.parseLong(cno);
	}
	
	public String getPrimary_contact() {
		return primary_contact;
	}
	public void setPrimary_contact(String primary_contact) {
		this.primary_contact = primary_contact;
	}
	
	public String getRecord_status() {
		return record_status;
	}
	public void setRecord_status(String record_status) {
		this.record_status = record_status;
	}
	
	public String getAiflag() {
		return aiflag;
	}
	public void setAiflag(String aiflag) {
		this.aiflag = aiflag;
	}
	
	public String getCreatedate() {
		return createdate;
	}
	public void setCreatedate(String createdate) {
		this.createdate = createdate;
	}
	
	public String getCreatedby() {
		return createdby;
	}
	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}
	
	public String getModifydate() {
		return modifydate;
	}
	public void setModifydate(String modifydate) {
		this.modifydate = modifydate;
	}
	
	public String getModifyby() {
		return modifyby;
	}
	public void setModifyby(String modifyby) {
		this.modifyby = modifyby;
	}
	
	public String getAuthdate() {
		return authdate;
	}
	public void setAuthdate(String authdate) {
		this.authdate = authdate;
	}
	
	public String getAuthby() {
		return authby;
	}
	public void setAuthby(String authby) {
		this.authby = authby;
	}

	@Override
	public String toString() {
		return "Customer [customer_id=" + customer_id + ", customer_code=" + customer_code + ", customer_name="
				+ customer_name + ", customer_add1=" + customer_add1 + ", customer_add2=" + customer_add2 + ", pincode="
				+ pincode + ", email=" + email + ", customer_contactno=" + customer_contactno + ", primary_contact="
				+ primary_contact + ", record_status=" + record_status + ", aiflag=" + aiflag + ", createdate="
				+ createdate + ", createdby=" + createdby + ", modifydate=" + modifydate + ", modifyby=" + modifyby
				+ ", authdate=" + authdate + ", authby=" + authby + "]";
	}
}
