package com.nucleus.makerchecker.model;

public class User {
	
	private int userid;
	private String username;
	private String password;
	private String category;
	
	public User(){
		
	}
	
	public User(int userid, String username, String password, String category) {
		super();
		this.userid = userid;
		this.username = username;
		this.password = password;
		this.category = category;
	}
	
	public int getUserid() {
		return userid;
	}
	
	public String getUsername() {
		return username;
	}
	
	public String getPassword() {
		return password;
	}
	
	public String getCategory() {
		return category;
	}
	
	public void setUserid(int userid) {
		this.userid = userid;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public void setCategory(String category) {
		this.category = category;
	}

	@Override
	public String toString() {
		return "User [userid=" + userid + ", username=" + username + ", password=" + password + ", category=" + category
				+ "]";
	}
}
