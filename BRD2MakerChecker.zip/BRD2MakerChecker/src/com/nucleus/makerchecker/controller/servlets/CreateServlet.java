package com.nucleus.makerchecker.controller.servlets;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.nucleus.makerchecker.dao.CustomerDao;
import com.nucleus.makerchecker.model.Customer;

public class CreateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		HttpSession session=request.getSession();
		String name=(String)session.getAttribute("name");
		
		String code=request.getParameter("customer_code");
		String cname=request.getParameter("customer_name");
		String add1=request.getParameter("customer_add1");
		String add2=request.getParameter("customer_add2");
		String pin=request.getParameter("pincode");
		String email=request.getParameter("email");
		String cno=request.getParameter("customer_contactno");
		String pcp=request.getParameter("primary_contact");
		String aif=request.getParameter("aiflag");
		
		System.out.println(code+cname+add1+add2+pin+email+cno+pcp+aif);
		
		Customer customer = new Customer();
		
		customer.setAiflag(aif);
		customer.setCustomer_name(cname);
		customer.setCreatedby(name);
		customer.setCustomer_add1(add1);
		customer.setCustomer_add2(add2);
		customer.setPincode(pin);
		customer.setEmail(email);
		customer.setCustomer_contactno(cno);
		customer.setPrimary_contact(pcp);
		customer.setCustomer_code(code);
		Date d=new  Date();
		customer.setCreatedate(d.toString());
		customer.setRecord_status("N");
		
		System.out.println(customer);
		
		CustomerDao customerDao = new CustomerDao();
		customerDao.addCustomer(customer);
		
		response.sendRedirect("welcome.jsp");
	}

}
