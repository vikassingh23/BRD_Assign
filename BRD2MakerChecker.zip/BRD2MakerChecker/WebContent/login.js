


$("#username").focusout(function(){
	//alert($("#username").val());
	var userval=$.trim($("#username").val());
	 
	if(!(userval.match(/^[a-zA-Z\s]+$/))){		
		alert("Please use char value");
		$(this).val("");
		
	}
});

$("#save").click(function(){
	var userval=$.trim($("#username").val());	 
	var passs=$.trim($("#password").val());	 
	if(userval !="" || passs!=""){
		$("#form").submit();
	}else{
		alert("Please fill all the values");
	}
});
